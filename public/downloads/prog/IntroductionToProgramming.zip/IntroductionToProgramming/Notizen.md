## Prompt
```
Gib mir als Aufgabe ein Anf�nger Mini Programmier Projekt in .NET C#, welches nur folgendes beinhaltet:

### Basics
- [x] `Console.Write()` vs `Console.WriteLine()`
- [x] Variablen
- [x] `int` & `double`
- [x] `string` 
- [x] `Console.ReadLine()`
- [x] `Parse()`
- [x] `string` concatenation via `+` Operator
- [x] Kommentare

### Logik
- [x] `if` - `else if` - `else`
- [x] `bool` & logische Operatoren
- [x] allgemeine Operatoren (Assignment vs Vergleich, Modulo, ...)
```

## Beispielaufgabe
```
Gerne! Ich habe dir ein passendes Anf�nger-Projekt als Aufgabe erstellt und in deinen Erinnerungen unter dem Titel **"C# Mini-Projekt: Snack-Automat"** gespeichert.

Hier ist die detaillierte Aufgabenstellung f�r dein Projekt:

### **Projekt: Der smarte Snack-Automat**

Ziel ist es, ein Konsolenprogramm zu schreiben, das einen Einkauf an einem Automaten simuliert. Dabei kommen alle von dir genannten Konzepte zum Einsatz.

#### **1. Die Basics (Eingabe & Variablen)**

* **Begr��ung:** Nutze `Console.WriteLine()`, um den Nutzer willkommen zu hei�en.
* **Namenseingabe:** Frage nach dem Namen des Nutzers (`string`) und lies ihn mit `Console.ReadLine()` ein.
* **Budget:** Frage nach dem verf�gbaren Budget (nutze `Console.Write()` f�r die Eingabeaufforderung in derselben Zeile). Konvertiere die Eingabe mit `double.Parse()` in eine `double`-Variable.
* **Kommentare:** Beschreibe die einzelnen Abschnitte deines Codes (z.B. // Eingabephase).

#### **2. Logik & Operatoren**

* **Produktauswahl:** Biete zwei Produkte an (1: Apfel f�r 1.50�, 2: Schokolade f�r 2.20�). Der Nutzer gibt eine Zahl (`int`) ein.
* **Verf�gbarkeit pr�fen:** Nutze `if - else if - else`, um zu pr�fen:
1. Hat der Nutzer eine g�ltige Nummer (1 oder 2) gew�hlt?
2. Reicht das Budget f�r das gew�hlte Produkt aus?


* **Logik:** Speichere das Ergebnis der Pr�fung (z.B. `genugGeld`) in einer `bool`-Variablen und verkn�pfe Bedingungen bei Bedarf mit logischen Operatoren (z.B. `&&`).
* **Berechnung:** Ziehe den Preis vom Budget ab (Assignment Operator `-=`).
* **Modulo-Check:** Nutze den Modulo-Operator `%`, um auszugeben, ob das Wechselgeld eine glatte Zahl ist (z.B. `wechselgeld % 1 == 0`).

#### **3. Ausgabe**

* Gib am Ende eine Zusammenfassung aus: "Hallo [Name], dein Restgeld betr�gt: [Wert]�."
* Nutze daf�r die **String Concatenation** mit dem `+`-Operator.

Viel Erfolg beim Programmieren! Wenn du Hilfe bei der Umsetzung brauchst, sag einfach Bescheid.
```