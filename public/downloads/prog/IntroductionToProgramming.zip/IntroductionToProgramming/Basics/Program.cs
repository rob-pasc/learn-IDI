﻿string? name;
int age;
bool isAdult = false;

Console.Write("Bitte gib deinen Namen ein: ");
name = Console.ReadLine();

Console.Write("Bitte gib dein Alter an: ");
string? input = Console.ReadLine();
age = int.Parse(input!);

//if (age < 18)
//{
//    isAdult = false;
//}
//else 
if (age >= 18)
{
    isAdult = true;
}

Console.WriteLine("Ich heiße: " + name);
Console.WriteLine("Ich bin " + age + " Jahre alt.");

if (isAdult)
{
    Console.WriteLine("Ich bin erwachsen.");
}
else if (!isAdult)
{
    Console.WriteLine("Ich bin noch minderjährig.");
}

int n = 0;
while (n < 10)
{
    Console.WriteLine("Hier die aktuelle Durchlaufzahl: " + n);
    n++;
}

/*
kebab-case
snake_case
camelCase
PascalCase

string a = "a";
string b = "b";
string c = a + b;
Console.WriteLine(c);   // Output: "ab"
*/